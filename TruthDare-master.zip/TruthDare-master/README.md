## **TruthDare**
A simple Truth or Dare game. Get your position around your phone and get started. If you wish you can add more truths and dares.

## **Icon**
![icon](src/icon.png)

## **Video**
![](src/video.gif)

## **Apk**
[app-debug.apk](src/app-debug.apk?raw=true)

## **License**
Licensed under the [MIT License](LICENSE)
