package madproject.p1.td;

public class TruthItem{

    private String mText;

    public TruthItem(String text) {
        mText = text;
    }

    public String getmText() {
        return mText;
    }

}