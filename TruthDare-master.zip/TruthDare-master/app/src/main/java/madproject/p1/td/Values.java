package madproject.p1.td;

public class Values {

    String[] truths = new String[]{
            "What's the most adventurous thing you've ever done?",
            "If you could live in any fictional world, which one would you choose and why?",
            "What's the silliest fear you have?",
            "Describe a time when you accidentally sent a text message to the wrong person. What was the message and how did you handle it?",
            "If you could only eat one food for the rest of your life, what would it be?",
            "What's the most embarrassing thing you've ever done to impress someone?",
            "Have you ever been caught doing something you shouldn't have? What was it and what was the consequence?",
            "What's the most spontaneous thing you've ever done?",
            "Describe a time when you were caught in a lie. What happened?",
            "If you could have dinner with any historical figure, who would it be and why?",
            "What's the funniest thing that has ever happened to you during a serious moment?",
            "If you could trade lives with your pet for a day, would you do it? Why or why not?",
            "Describe a time when you accidentally insulted someone. How did you make up for it?",
            "What's the weirdest talent you have?",
            "If you could time travel to any era, which one would you choose and why?",
            "What's the most memorable dream you've ever had?",
            "Describe a time when you witnessed something paranormal or unexplainable. How did you feel?",
            "If you could be any animal for a day, which one would you choose and why?",
            "What's the most embarrassing thing your parents have ever done in front of you?",
            "Describe a time when you laughed so hard you couldn't stop. What was so funny?",
            "If you could only listen to one song for the rest of your life, what would it be?",
            "What's the most unusual pet you've ever had?",
            "What's the most interesting thing you've ever found on the internet?",
            "Describe a time when you got caught in a rainstorm without an umbrella. What did you do?",
            "If you could have any job in the world, what would it be and why?",
            "What's the most embarrassing thing you've ever worn in public?"
    };

    String[] dares = new String[]{
            "Rate everyone in the room from 1 to 10, with 10 being the best personality.",
            "Go next door with a measuring cup and ask for a cup of sugar.",
            "Open Facebook, go to the account of the first person you see, and like every post on their wall going back to a year.",
            "Call your crush.", "Get into a debate with a wall.", "Eat a spoonful of mustard.",
            "Write a letter to your doctor describing an embarrassing rash you have, and post it on Facebook.",
            "Let the group choose three random things from the refrigerator and mix them together. Then you have to eat it.",
            "Dig through the trash and name everything you find.",
            "Call a NY-style pizza place and ask them what the difference is between NY pizza and “real” pizza.",
            "Take a selfie with the toilet and post it online.",
            "Sing the chorus of your favorite song out loud in the cafeteria.",
            "Do your best impression of a teacher.",
            "Dance for one minute without any music.",
            "Do an impression of your favorite cartoon character.",
            "Let someone else style your hair however they want.",
            "Speak in an accent for the next three rounds.",
            "Do your best robot dance for one minute.",
            "Tell a joke to a stranger.",
            "Balance a book on your head while walking around the room.",
            "Recite a tongue twister five times without making a mistake.",
            "Do ten push-ups in the middle of the classroom.",
            "Speak only in rhymes for the next three rounds.",
            "Eat a spoonful of a condiment you dislike.",
            "Wear your clothes backward for the next hour.",
            "Do an interpretive dance to a nursery rhyme.",
            "Do your best impression of a celebrity."
    };
}
