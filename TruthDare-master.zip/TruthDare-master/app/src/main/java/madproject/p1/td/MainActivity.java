package madproject.p1.td;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import madproject.p1.td.R;

import java.util.ArrayList;
import java.util.Random;

import madproject.p1.td.R;

public class MainActivity extends AppCompatActivity {

    private Button btn, truthBtn, dareBtn;
    private ImageView imgView;
    private Random random = new Random();
    private int lastDirection;
    private MediaPlayer mp;
    private LinearLayout linearLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.button);
        truthBtn = findViewById(R.id.btn1);
        dareBtn = findViewById(R.id.btn2);
        imgView = findViewById(R.id.imageView);
        Button removeAllPlayers = findViewById(R.id.removeAllPlayers);
        linearLayout = findViewById(R.id.linearlayout); // Assuming you have a parent LinearLayout in your layout XML file with id "parentLayout"

        removeAllPlayers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
                dbHelper.deleteAllPlayers();

                // Update UI or show a message indicating success
                linearLayout.removeAllViews(); // Clear the displayed names
                Toast.makeText(MainActivity.this, "All players removed", Toast.LENGTH_SHORT).show();
            }
        });

        truthBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), TruthActivity.class));
            }
        });

        dareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), DareActivity.class));
            }
        });

        // Retrieve names from the database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        ArrayList<String> names = dbHelper.getAllNames();

        linearLayout.removeAllViews(); // Clear previous views

        for (final String name : names) {
            // Create a horizontal LinearLayout for each player
            LinearLayout playerLayout = new LinearLayout(this);
            playerLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            playerLayout.setOrientation(LinearLayout.HORIZONTAL);

            // Create a TextView to display the player name
            TextView textView = new TextView(this);
            textView.setLayoutParams(new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1.0f
            ));
            textView.setText(name);
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 23);

            // Create TextView to display the player's points
            final TextView pointsTextView = new TextView(this);
            pointsTextView.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            pointsTextView.setText("0"); // Initial points set to 0
            pointsTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 23);

            // Create increment Button
            Button incrementButton = new Button(this);
            incrementButton.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            incrementButton.setText("+");
            // Add onClickListener to increment points for the player
            incrementButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int currentPoints = Integer.parseInt(pointsTextView.getText().toString());
                    if (currentPoints < 15) {
                        currentPoints++;
                        pointsTextView.setText(String.valueOf(currentPoints));
                    }
                }
            });

            // Create decrement Button
            Button decrementButton = new Button(this);
            decrementButton.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            decrementButton.setText("-");
            // Add onClickListener to decrement points for the player
            decrementButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int currentPoints = Integer.parseInt(pointsTextView.getText().toString());
                    if (currentPoints > 0) {
                        currentPoints--;
                        pointsTextView.setText(String.valueOf(currentPoints));
                    }
                }
            });

            // Add TextView, pointsTextView, and Buttons to the player layout
            playerLayout.addView(textView);
            playerLayout.addView(pointsTextView);
            playerLayout.addView(incrementButton);
            playerLayout.addView(decrementButton);

            // Add player layout to the main LinearLayout
            linearLayout.addView(playerLayout);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        truthBtn.setEnabled(false);
        dareBtn.setEnabled(false);
        btn.setEnabled(true);
    }

    public void spin(View view) {

        int newDirection = random.nextInt(5400);
        float pivotX = imgView.getWidth()/2;
        float pivotY = imgView.getHeight()/2;

        Animation rotate = new RotateAnimation(lastDirection, newDirection, pivotX, pivotY);
        rotate.setDuration(2000);
        rotate.setFillAfter(true);
        rotate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mp = MediaPlayer.create(MainActivity.this, R.raw.audio);
                mp.start();
                btn.setEnabled(false);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mp.stop();
                mp.release();
                mp = null;
                truthBtn.setEnabled(true);
                dareBtn.setEnabled(true);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        lastDirection = newDirection;
        imgView.startAnimation(rotate);
    }
}